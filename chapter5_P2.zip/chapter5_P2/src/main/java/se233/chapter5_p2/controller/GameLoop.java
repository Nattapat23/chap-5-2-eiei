package se233.chapter5_p2.controller;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import se233.chapter5_p2.model.Direction;
import se233.chapter5_p2.model.Food;
import se233.chapter5_p2.model.Snake;
import se233.chapter5_p2.view.GameStage;

public class GameLoop implements Runnable {
    private GameStage gameStage;
    private Snake snake;
    private Food food;
    private final Stage stage;
    private float interval = 1000.0f /10 ;
    private boolean running;
    public GameLoop(GameStage gameStage, Snake snake, Food food , Stage stage) {
        this.gameStage = gameStage;
        this.snake = snake;
        this.stage = stage;
        this.food = food;
        running = true;
    }
    private void keyProcess() {
        KeyCode curKey = gameStage.getKey();
        if (curKey == null) return;
        Direction curDirection = snake.getDirection();
        if (curKey == KeyCode.UP && curDirection != Direction.DOWN)
            snake.setDirection(Direction.UP);
        else if (curKey == KeyCode.DOWN && curDirection != Direction.UP)
            snake.setDirection(Direction.DOWN);
        else if (curKey == KeyCode.LEFT && curDirection != Direction.RIGHT)
            snake.setDirection(Direction.LEFT);
        else if (curKey == KeyCode.RIGHT && curDirection != Direction.LEFT)
            snake.setDirection(Direction.RIGHT);
    }

    private void update() {
        snake.move();
    }
    private void checkCollision(){

        if (snake.collided(food)) {
            snake.grow(food);
            food.respawn();
        }
        if (snake.checkDead()){
            running = false;
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Game Over");
                alert.setHeaderText(null);
                alert.setContentText("Game Over! Final Score: "+ snake.getScore());
                alert.showAndWait();
                Platform.exit();
            });

        }

    }
    private void redraw(){
        Platform.runLater(() -> stage.setTitle("Snake Game | Score: " + snake.getScore()));
        gameStage.render(snake, food);
    }
    @Override
    public void run() {
        while (running) {
            keyProcess();
            update();
            checkCollision();
            redraw();
            try {
                Thread.sleep((long) interval);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}
